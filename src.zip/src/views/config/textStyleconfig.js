let textStyleConfig = {
  textStyle: {
    decoration: 'none',
    fontFamily: 'Arial, Verdana, sans-serif',
    fontFamily2: '微软雅黑',    // IE8- 字体模糊并且不支持不同字体混排，额外指定一份
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: 'normal'
  }
}
