let kconfig = {
  itemStyle: {
    normal: {
      color: '#fff',
      color0: '#00aa11',
      lineStyle: {
        width: 1,
        color: '#ff3200',
        color0: '#00aa11'
      }
    },
    emphasis: {
    }
  }
}
