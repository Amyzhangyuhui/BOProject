let scatterconfig = {
  symbolSize: 4,
  large: false,
  largeThreshold: 2000,
  itemStyle: {
    normal: {
      label: {
        show: false
      }
    },
    emphasis: {
      label: {
        show: false
      }
    }
  }
}
