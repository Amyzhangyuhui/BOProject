let radarconfig = {
  itemStyle: {
    normal: {
      label: {
        show: false
      },
      lineStyle: {
        width: 2,
        type: 'solid'
      }
    },
    emphasis: {
      label: {
        show: false
      }
    }
  },
  symbolSize: 2
}
